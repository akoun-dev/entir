
// Define Job interface separately to avoid ambiguity
export interface Job {
  id: string;
  name: string;
  department_id: string;
}
