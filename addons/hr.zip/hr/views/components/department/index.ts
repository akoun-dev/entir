
export { default as DepartmentHeader } from './DepartmentHeader';
export { default as DepartmentDescription } from './DepartmentDescription';
export { default as SubDepartmentsTable } from './SubDepartmentsTable';
export { default as EmployeesTable } from './EmployeesTable';
