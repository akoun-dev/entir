
export { default as EmployeeProfileHeader } from './EmployeeProfileHeader';
export { default as EmployeeGeneralInfo } from './EmployeeGeneralInfo';
export { default as EmployeeContractsTab } from './EmployeeContractsTab';
export { default as EmployeeDocumentsTab } from './EmployeeDocumentsTab';
export { default as EmployeeDetailHeader } from './EmployeeDetailHeader';
