
/**
 * Liste des départements de l'entreprise
 */
export const departments = [
  { id: '1', name: 'Direction Générale' },
  { id: '2', name: 'Ressources Humaines' },
  { id: '3', name: 'Finance et Comptabilité' },
  { id: '4', name: 'Marketing et Ventes' },
  { id: '5', name: 'Recherche et Développement' },
  { id: '6', name: 'Production' },
  { id: '7', name: 'Technologies de l\'Information' },
];
