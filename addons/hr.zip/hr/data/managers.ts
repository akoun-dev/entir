
/**
 * Liste des managers de l'entreprise
 */
export const managers = [
  { id: '1', name: 'Fanta Keita' },
  { id: '2', name: 'Albert Kouassi' },
  { id: '3', name: 'Sophie Mensah' },
];
