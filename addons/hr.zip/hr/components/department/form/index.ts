
export { default as DepartmentBasicInfo } from './DepartmentBasicInfo';
export { default as DepartmentRelations } from './DepartmentRelations';
export { default as DepartmentAppearance } from './DepartmentAppearance';
