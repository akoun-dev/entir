
export { default as TabGeneral } from './TabGeneral';
export { default as TabMembers } from './TabMembers';
export { default as TabJobs } from './TabJobs';
export { default as DepartmentFormHeader } from './DepartmentFormHeader';
export { default as DepartmentGeneralForm } from './DepartmentGeneralForm';
export * from './form';
