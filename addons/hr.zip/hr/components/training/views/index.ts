
export { default as TrainingHeader } from './TrainingHeader';
export { default as TrainingNavBar } from './TrainingNavBar';
export { default as TrainingTabsContainer } from './TrainingTabsContainer';
export { default as CourseTabContent } from './CourseTabContent';
export { default as SessionTabContent } from './SessionTabContent';
export { default as EnrollmentTabContent } from './EnrollmentTabContent';
