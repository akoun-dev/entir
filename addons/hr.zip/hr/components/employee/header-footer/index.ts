
export { default as HeaderTab } from './HeaderTab';
export { default as FooterTab } from './FooterTab';
export { default as ProfileHeaderFooter } from './ProfileHeaderFooter';
