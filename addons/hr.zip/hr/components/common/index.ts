
// Export all common components
export { default as TabContent } from './TabContent';
